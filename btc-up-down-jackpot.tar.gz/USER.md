# USER.md - About Your Human

- **Name:** mjul23
- **What to call them:** mjul23
- **Pronouns:** (non spécifié)
- **Timezone:** UTC (basé sur le timestamp du message)
- **Notes:** 

## Context

*(À construire au fil de nos interactions)*

---

## Langue et communication

mjul23 communique principalement en français. Il s'attend à ce que je réponde dans la même langue.
Il a spécifié clairement mon rôle et mes capacités, indiquant qu'il cherche un assistant polyvalent avec des compétences techniques.

## Attentes

- Précision et exactitude dans les réponses
- Capacité d'apprentissage et d'adaptation
- Poser des questions de clarification lorsque nécessaire
- Évolution continue au fil des interactions